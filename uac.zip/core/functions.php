<?php
// common start

function alert($data, $color="danger") {
    return "<p class='alert alert-$color'>$data</p>";
}

function run_query($sql) {
   
    if(mysqli_query(con(), $sql)) {
      return true;
    } else {
        die("Query Failed: " .mysqli_error());
    }

}

function redirect($location) {
    header("location: $location");
}
// common end

// auth start

function register() {
    
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $cpassword = $_POST["cpassword"];

   

    if($password == $cpassword) {

       $secure_password = password_hash($password, PASSWORD_DEFAULT);
       $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$secure_password')";
       if(run_query($sql)) {
           redirect("login.php");
       } 

    } else {

        return alert("Password do not match!!!");

    }

}

function login() {

    $email = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $query = mysqli_query(con(), $sql);
    $row = mysqli_fetch_assoc($query);
    
    if(!$row) {

        return alert("Email or Password do not correct!!!");

    } else {

        if(!password_verify($password, $row['password'])) {

            return alert("Email or Password do not correct!!!");

        } else {

            session_start();

            $_SESSION['user'] = $row;
            
            redirect("dashboard.php");

        }

    }

}

// auth end