<?php require_once "core/auth.php"; ?>
<?php require_once "template/header.php"; ?>

    <h1>This is dashboard</h1>

    <?php 
    
    echo "<pre>";
    print_r($_SESSION['user']);
    ?>

<?php require_once "template/footer.php"; ?>



